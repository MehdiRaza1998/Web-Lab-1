<?php
function myPow($base, $exponent) {
  $result = 1;
  for($i = 0; $i< $exponent; $i++) {
    $result *= $base;
  }
  return $result;

}
echo "Exponent is:". myPow(3,2);
?>