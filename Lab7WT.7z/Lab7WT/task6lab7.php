<?php
for ( $i = 1; $i <= 7; $i++) {
for ( $j = 1; $j <= 7; $j++) {
print(($i * $j) ." ");
}
print("<br>");

}




?>