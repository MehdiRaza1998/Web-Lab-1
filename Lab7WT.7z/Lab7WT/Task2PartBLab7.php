<?php
$stack=array("4", "5","6","7","8","9");
array_push($stack, "$", "@","%");
array_shift($stack)."<br>";
echo '<pre>'; print_r($stack); echo '</pre>';
?>