<?php
 echo implode(",",range(400,300,4))."\n";
?>