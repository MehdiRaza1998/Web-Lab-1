<?php

$name=$_POST['name'];
$email= $_POST['email'];
$phone=$_POST['phone'];
$msg= $_POST['message'];

print "Welcome ".$name."<br>";
print  "email: ".$email."<br>";
print  "phone-no: ".$phone."<br>";
print  "Message: ".$msg."<br>";

?>