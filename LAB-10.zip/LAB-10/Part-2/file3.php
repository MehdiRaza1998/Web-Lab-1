<?php
$lines=fopen("New Text Document.txt", "w+");
echo($lines);

$result=fwrite($lines, "HELLO 16SW");
if ($result) {
	echo("Written Successfully");

}
else{
	echo ("Failure");
}
$lines=file("New Text Document.txt");
echo (implode($lines));
if (file_exists("doc.txt")) {
	copy("doc.txt", "85.docx");
	echo "File Copied";
	rename("85.docx", "hi.docx");
	echo "File Renamed";
	unlink("hi.docx");
	echo "File Deleted";
}
?>