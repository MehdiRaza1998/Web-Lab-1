<?php
$lines=file_get_contents("doc.txt");
echo "Words=".$lines."<br>";
echo str_word_count($lines)."<br>";
$arrwords=explode($lines, "doc.txt");
echo count($arrwords)."<br>";
if (file_exists("doc.txt")){
	copy("doc.txt", "doc.pdf");
	echo "Converted Successfully"."<br>";
}
$handle = fopen("doc.txt" ,'a');
$data = '16SW85';
fwrite($handle, $data);
echo "Hello 16SW85";


?>