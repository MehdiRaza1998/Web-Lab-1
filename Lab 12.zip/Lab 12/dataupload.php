<?php 
include "connection.php";

$Query = mysqli_query($con, "LOAD DATA LOCAL INFILE 'data.txt' INTO TABLE students FIELDS TERMINATED BY ','");
	if($Query){
		echo "<script>alert('Student record is successfully inserted!')</script>";
	}else{
		echo mysqli_error($con);
	}

?>