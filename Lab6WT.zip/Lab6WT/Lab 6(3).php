<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
	<?php 
	#3.	To swap two variables and print their values before and after swapping.
	$a = 20;
$b = 380;
echo "\nBefore swapping:  ". $a . ',' . $b;
echo "<br>";
list($a, $b) = array($b, $a);
echo "\nAfter swapping:  ". $a . ',' . $b."\n";

	?>

</body>
</html>