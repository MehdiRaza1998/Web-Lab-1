<?php
	/*•	Write PHP code inside HTML for the following:
Create a variable $var = 'PHP Lab 6'. Put this variable into the title section, h3 tag and as an anchor text within an HTML document to print its value in all of them i.e. in title, h3 tag and anchor tag text.
Hint: Save the file with .php extension and run according to PHP basics in the browser. Use echo function between HTML tags to print the value of PHP variable.

	*/
$a = 'PHPlab6';
?>
<html>
<head>
  <meta http-equiv="content-type" content="text/html; charset=utf-8">
  <title><?php echo $a; ?> Php !</title>
  </head>

  <body>
  	
  <h3><?php echo $a; ?></h3>
  <p>This the lab 6 Task7 part(b) And I have done it</p>
  <p><a href="http://localhost/var.php">Go to the <?php echo $a; ?></a>.</p>
</body>
</html>
	

	 

