<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
	<?php 
	/* 7.	To return the following components of any url stored in a variable such as:

url: http://sw.muet.edu.pk/faculty/cvs/sample.pdf		
Scheme : http
Host : www.sw.muet.edu.pk
Path : /faculty/cvs/sample.pdf

Hint: Use string functions to extract various components from the url

	*/
$url = 'http://sw.muet.edu.pk/faculty/cvs/sample.pdf	';
$url=parse_url($url);
echo 'Scheme : '.$url['scheme']."\n";
echo "<br>";
echo 'Host : '.$url['host']."\n";
echo "<br>";
echo 'Path : '.$url['path']."\n";
	?>

</body>
</html>