<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
	<?php
	#6.	To test whether a number is greater than 30, 20 or 10 using ternary operator and print the result.
	function trinary_Test($n){
$r = $n > 30
? "greater than 30"


: ($n > 20
? "greater than 20"

: ($n >10
? "greater than 10"

: "Input a number atleast greater than 10!")); 
echo $n." : ".$r."<br>";
}
trinary_Test(38);
trinary_Test(26);
trinary_Test(19);
trinary_Test(7);
 

	?>

</body>
</html>