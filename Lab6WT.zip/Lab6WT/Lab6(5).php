<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
	<?php
	/*5.	To display the following strings:

Tomorrow I’ll learn something new.
This is a bad command: del c:\*.*\$.*/
echo 'Tomorrow I \'ll learn something new.<br />'; 
echo 'This is a bad command : del c:\\*.*\$ <br />'; 

 

	?>

</body>
</html>