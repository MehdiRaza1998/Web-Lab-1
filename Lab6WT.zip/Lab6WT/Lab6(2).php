<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
	<?php 
	#2.	To get the name of the owner of the current PHP script, document root directory under which the current script is running and the operating system PHP is running on. 
	 phpinfo();
	?>

</body>
</html>