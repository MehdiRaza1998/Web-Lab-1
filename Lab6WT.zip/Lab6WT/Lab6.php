<!DOCTYPE html>
<html>
<head>
	<title>Lab6/title>
</head>
<body>

	<?php 
	#1.	To get the PHP version and configuration information.
 
echo 'Tomorrow I \'ll learn something new.<br />'; 
echo 'This is a bad command : del c:\\*.*\$ <br />'; 
?>

</body>
</html>